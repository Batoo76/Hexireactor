/**
 * keynetik info
 */

#pragma once

#define KEYNETIK_STEP            ( 1 )
#define KEYNETIK_ACTIVITYCHANGED ( 2 )